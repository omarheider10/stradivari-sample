# Stradivari braid sample

Interactive standalone viewer for the exact Stradivari PET braid added to the Blender project.

- 192 geometric filaments: 32 bundles in each direction, three filaments per bundle.
- Outer diameter 14.6 mm; inner diameter 13.404 mm; sleeve length 47 mm.
- Original navy material and microfinish textures; the weave itself is full mesh geometry.
- Rotate, pan and zoom; Whole sleeve, Braid detail and Wire ends presets.

Geometry and material reference: https://iobjectm.com/demos/stradivari-cable/
The geometry is the same losslessly decoded source verified in the Blender deliverable. The source mesh uses meshopt compression for transfer, with no decimation or baked braid replacement.

This repository is separate from the original nylon-sample project. GitHub Pages deploys the contents of `Stradivari Sample.zip` using the included workflow. Three.js retains its MIT license in vendor/three/LICENSE.
