import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {RGBELoader} from 'three/addons/loaders/RGBELoader.js';
import {RectAreaLightUniformsLib} from 'three/addons/lights/RectAreaLightUniformsLib.js';
import {MeshoptDecoder} from './meshopt-decoder.js';

const host=document.querySelector('#cable'),status=document.querySelector('#status');
const views={whole:{target:[-34,0,0],orbit:[22,68,165]},detail:{target:[-43,3,1],orbit:[22,60,47]},cutends:{target:[-18,0,0],orbit:[55,64,44]}};
try{
 RectAreaLightUniformsLib.init();
 const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:'high-performance'});
 renderer.setPixelRatio(Math.min(devicePixelRatio,1.25));renderer.setClearColor(0,0);
 renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.1;
 renderer.domElement.tabIndex=0;renderer.domElement.setAttribute('aria-label','Navy Stradivari braid with individual woven filaments. Drag to rotate, scroll or pinch to zoom.');
 host.appendChild(renderer.domElement);
 const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(30,1,.01,2000),controls=new OrbitControls(camera,renderer.domElement);
 controls.enableDamping=true;controls.dampingFactor=.15;controls.rotateSpeed=.65;controls.zoomSpeed=.8;controls.panSpeed=.5;controls.minDistance=9;controls.maxDistance=550;controls.listenToKeyEvents(renderer.domElement);
 let transition=null,pending=false,last=0;
 function pose(id){const v=views[id],target=new THREE.Vector3(...v.target),position=new THREE.Vector3().setFromSphericalCoords(v.orbit[2],THREE.MathUtils.degToRad(v.orbit[1]),THREE.MathUtils.degToRad(v.orbit[0])).add(target);return{target,position};}
 const start=pose('whole');camera.position.copy(start.position);controls.target.copy(start.target);controls.update();
 function frame(time){pending=false;const dt=Math.min(Math.max((time-last)/1000,.016),.05);last=time;let moving=false;if(transition){const step=1-Math.exp(-dt/.10);controls.target.lerp(transition.target,step);camera.position.lerp(transition.position,step);if(camera.position.distanceToSquared(transition.position)<1e-5&&controls.target.distanceToSquared(transition.target)<1e-5){controls.target.copy(transition.target);camera.position.copy(transition.position);transition=null;}else moving=true;}moving=controls.update()||moving;renderer.render(scene,camera);if(moving)requestFrame();}
 function requestFrame(){if(!pending){pending=true;requestAnimationFrame(frame);}}
 controls.addEventListener('change',requestFrame);controls.addEventListener('start',()=>{transition=null;requestFrame();});controls.addEventListener('end',requestFrame);
 for(const id of Object.keys(views))document.querySelector('#'+id).onclick=()=>{transition=pose(id);document.querySelectorAll('nav button').forEach(b=>b.setAttribute('aria-pressed',String(b.id===id)));last=performance.now();requestFrame();};
 const resize=()=>{const w=host.clientWidth,h=host.clientHeight;camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h,false);requestFrame();};new ResizeObserver(resize).observe(host);resize();
 scene.add(new THREE.HemisphereLight(0xffffff,0x253044,.14));
 for(const rig of [{position:[0,110,85],target:[0,0,0],width:180,height:55,intensity:4,color:0xfffaf3},{position:[150,35,65],target:[45,0,0],width:100,height:100,intensity:.65,color:0xffffff},{position:[-35,50,-100],target:[-10,0,0],width:150,height:90,intensity:1.3,color:0xe9f0ff}]){const light=new THREE.RectAreaLight(rig.color,rig.intensity,rig.width,rig.height);light.position.set(...rig.position);light.lookAt(...rig.target);scene.add(light);}
 const pmrem=new THREE.PMREMGenerator(renderer);pmrem.compileEquirectangularShader();
 const loader=new GLTFLoader().setMeshoptDecoder(MeshoptDecoder);
 const [braid,jacket,hdr]=await Promise.all([loader.loadAsync('./stradivari-braid.glb',e=>{if(e.total)status.textContent=`Loading the braid… ${Math.round(e.loaded/e.total*100)}%`;}),loader.loadAsync('./jacket.glb'),new RGBELoader().loadAsync('./studio.hdr')]);
 scene.environment=pmrem.fromEquirectangular(hdr).texture;scene.environmentIntensity=.5;scene.environmentRotation.y=Math.PI/2;hdr.dispose();pmrem.dispose();
 for(const model of [braid,jacket]){model.scene.scale.setScalar(1000);model.scene.traverse(o=>{if(o.isMesh&&o.morphTargetInfluences)o.morphTargetInfluences.fill(0);});scene.add(model.scene);}
 host.dataset.filaments='192';host.dataset.outerDiameterMm='14.6';host.dataset.lengthMm='47';document.documentElement.dataset.modelLoaded='true';status.textContent='';status.hidden=true;
 document.querySelectorAll('nav button').forEach(b=>b.disabled=false);requestFrame();
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)requestFrame();});
 renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();status.hidden=false;status.textContent='The 3D view was interrupted. Reload the page to continue.';});
}catch(error){console.error(error);status.hidden=false;status.textContent='The model could not load. Please reload the page.';document.documentElement.dataset.modelLoaded='false';}
